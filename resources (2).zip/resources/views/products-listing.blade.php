@extends('app')
@section("main")
<table>
    <h2 class="table-title">Dried - Bulk</h2>
    <thead>
      <th>Item</th>
      <th>Name</th>
      <th>Packing</th>
    </thead>

    <tbody>
      <tr>
        <td data-label="item">GRPL003</td>
        <td data-label="name">Black Eye Peas	</td>
        <td data-label="packing">50 lbs.</td>
      </tr>
      <tr>
        <td data-label="item">GRPL003</td>
        <td data-label="name">Black Eye Peas	</td>
        <td data-label="packing">50 lbs.</td>
      </tr>
      <tr>
        <td data-label="item">GRPL003</td>
        <td data-label="name">Black Eye Peas	</td>
        <td data-label="packing">50 lbs.</td>
      </tr>
      <tr>
        <td data-label="item">GRPL003</td>
        <td data-label="name">Black Eye Peas	</td>
        <td data-label="packing">50 lbs.</td>
      </tr>
      <tr>
        <td data-label="item">GRPL003</td>
        <td data-label="name">Black Eye Peas	</td>
        <td data-label="packing">50 lbs.</td>
      </tr>
      <tr>
        <td data-label="item">GRPL003</td>
        <td data-label="name">Black Eye Peas	</td>
        <td data-label="packing">50 lbs.</td>
      </tr>
      <tr>
        <td data-label="item">GRPL003</td>
        <td data-label="name">Black Eye Peas	</td>
        <td data-label="packing">50 lbs.</td>
      </tr>
      <tr>
        <td data-label="item">GRPL003</td>
        <td data-label="name">Black Eye Peas	</td>
        <td data-label="packing">50 lbs.</td>
      </tr>
      <tr>
        <td data-label="item">GRPL003</td>
        <td data-label="name">Black Eye Peas	</td>
        <td data-label="packing">50 lbs.</td>
      </tr>
      <tr>
        <td data-label="item">GRPL003</td>
        <td data-label="name">Black Eye Peas	</td>
        <td data-label="packing">50 lbs.</td>
      </tr>
    </tbody>
  </table>

  <table>
    <h2 class="table-title">heelo</h2>
    <thead>
      <th>Item</th>
      <th>Name</th>
      <th>Packing</th>
    </thead>

    <tbody>
      <tr>
        <td data-label="item">GRPL003</td>
        <td data-label="name">Black Eye Peas	</td>
        <td data-label="packing">50 lbs.</td>
      </tr>
      <tr>
        <td data-label="item">GRPL003</td>
        <td data-label="name">Black Eye Peas	</td>
        <td data-label="packing">50 lbs.</td>
      </tr>
      <tr>
        <td data-label="item">GRPL003</td>
        <td data-label="name">Black Eye Peas	</td>
        <td data-label="packing">50 lbs.</td>
      </tr>
      <tr>
        <td data-label="item">GRPL003</td>
        <td data-label="name">Black Eye Peas	</td>
        <td data-label="packing">50 lbs.</td>
      </tr>
      <tr>
        <td data-label="item">GRPL003</td>
        <td data-label="name">Black Eye Peas	</td>
        <td data-label="packing">50 lbs.</td>
      </tr>
      <tr>
        <td data-label="item">GRPL003</td>
        <td data-label="name">Black Eye Peas	</td>
        <td data-label="packing">50 lbs.</td>
      </tr>
      <tr>
        <td data-label="item">GRPL003</td>
        <td data-label="name">Black Eye Peas	</td>
        <td data-label="packing">50 lbs.</td>
      </tr>
      <tr>
        <td data-label="item">GRPL003</td>
        <td data-label="name">Black Eye Peas	</td>
        <td data-label="packing">50 lbs.</td>
      </tr>
      <tr>
        <td data-label="item">GRPL003</td>
        <td data-label="name">Black Eye Peas	</td>
        <td data-label="packing">50 lbs.</td>
      </tr>
      <tr>
        <td data-label="item">GRPL003</td>
        <td data-label="name">Black Eye Peas	</td>
        <td data-label="packing">50 lbs.</td>
      </tr>
    </tbody>
  </table>

  <table>
    <h2 class="table-title">heelo</h2>
    <thead>
      <th>Item</th>
      <th>Name</th>
      <th>Packing</th>
    </thead>

    <tbody>
      <tr>
        <td data-label="item">GRPL003</td>
        <td data-label="name">Black Eye Peas	</td>
        <td data-label="packing">50 lbs.</td>
      </tr>
      <tr>
        <td data-label="item">GRPL003</td>
        <td data-label="name">Black Eye Peas	</td>
        <td data-label="packing">50 lbs.</td>
      </tr>
      <tr>
        <td data-label="item">GRPL003</td>
        <td data-label="name">Black Eye Peas	</td>
        <td data-label="packing">50 lbs.</td>
      </tr>
      <tr>
        <td data-label="item">GRPL003</td>
        <td data-label="name">Black Eye Peas	</td>
        <td data-label="packing">50 lbs.</td>
      </tr>
      <tr>
        <td data-label="item">GRPL003</td>
        <td data-label="name">Black Eye Peas	</td>
        <td data-label="packing">50 lbs.</td>
      </tr>
      <tr>
        <td data-label="item">GRPL003</td>
        <td data-label="name">Black Eye Peas	</td>
        <td data-label="packing">50 lbs.</td>
      </tr>
      <tr>
        <td data-label="item">GRPL003</td>
        <td data-label="name">Black Eye Peas	</td>
        <td data-label="packing">50 lbs.</td>
      </tr>
      <tr>
        <td data-label="item">GRPL003</td>
        <td data-label="name">Black Eye Peas	</td>
        <td data-label="packing">50 lbs.</td>
      </tr>
      <tr>
        <td data-label="item">GRPL003</td>
        <td data-label="name">Black Eye Peas	</td>
        <td data-label="packing">50 lbs.</td>
      </tr>
      <tr>
        <td data-label="item">GRPL003</td>
        <td data-label="name">Black Eye Peas	</td>
        <td data-label="packing">50 lbs.</td>
      </tr>
    </tbody>
  </table>

  <style>

table {
  margin: 50px 0;
  width: 100%;
  border-spacing: 0;
  border-radius: var(--border-radius);
  overflow: hidden;
}
 .table-title {
    font-size: 2.4rem;
    font-weight: 400;
    text-align: center;
    margin: 30px auto 0 auto;
    color: #fff;
    background: var(--main-color);
    max-width: 1200px;
    border-radius: var(--border-radius);
}

thead {
 visibility: hidden;
 position: absolute;
 width: 0;
 height: 0;
}

th {
  background: var(--main-color);
  color: #fff;
}

td:nth-child(1) {
  background: var(--main-color);
  color: #fff;
  border-radius: var(--border-radius) var(--border-radius) 0 0;
}

th, td {
  padding: 1em;
}

tr, td {
  display: block;
}

td {
  position: relative;
}

td::before {
  content: attr(data-label);
  position: absolute;
  left: 0;
  padding-left: 1em;
  font-weight: 600;
  font-size: .9em;
  text-transform: uppercase;
}

tr {
  margin-bottom: 1.5em;
  border: 1px solid #ddd;
  border-radius: var(--border-radius);
  text-align: right;
}

tr:last-of-type {
  margin-bottom: 0;
}

td:nth-child(n+2):nth-child(odd) {
  background-color: #ddd;
}


@media only screen and (min-width: 768px) {

  table {
    max-width: 1200px;
    margin: 0 auto 30px auto;
    border: 1px solid #ddd;
  }

  thead {
    visibility: visible;
    position: relative;
  }

  th {
    text-align: left;
    text-transform: uppercase;
    font-size: .9em;
  }

  tr {
    display: table-row;
    border: none;
    border-radius: 0;
    text-align: left;
  }

  tr:nth-child(even) {
  background-color: #ddd;
}

  td {
    display: table-cell;
  }

  td::before {
    content: none;
  }

  td:nth-child(1) {
    background: transparent;
    color: #444;
    border-radius: 0;
  }

  td:nth-child(n+2):nth-child(odd) {
    background-color: transparent;
  }
}
  </style>
@stop
