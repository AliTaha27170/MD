@extends('app')

@section('main')
<h1>body</h1>
@stop