<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>New Order</title>
</head>
<body>
    <center><h3>
       <br> Thank you for placing your 
        order. <br><br>We will contact you if we have any questions. <br><br><br><br></h3>
    {!! $msg !!}
</center>
</body>
</html>

